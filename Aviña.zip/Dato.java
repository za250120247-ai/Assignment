public class Dato {
    private double valor;

    public Dato(double v) {
        valor = v;
    }

    public double get() { return valor; }
}
