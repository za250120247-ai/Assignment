import java.util.ArrayList;
import java.util.Arrays;

public class TablaFrecuencias {

    private ArrayList<Categoria> t3;   // HO3
    private ArrayList<Categoria> t4;   // HO4

    private double[] datos;            // para HO4 y HO5

    public TablaFrecuencias(String[] noms, int[] frecs, double[] datosHO4) {
        crearHO3(noms, frecs);
        datos = datosHO4;
        crearHO4();
    }

    // ============================
    //   HANDS-ON 3
    // ============================
    private void crearHO3(String[] nombres, int[] frecs) {
        t3 = new ArrayList<>();
        int total = 0;

        for (int f : frecs) total += f;

        for (int i = 0; i < nombres.length; i++) {
            t3.add(new Categoria(nombres[i], frecs[i], total));
        }
    }

    public void imprimirHO3() {
        System.out.println("\n----- HANDS-ON 3 -----");
        System.out.printf("%-10s %-5s %-6s %-6s\n", "Clase", "f", "fr", "%");

        int suma = 0;

        for (Categoria c : t3) {
            System.out.printf("%-10s %-5d %-6.2f %-6.1f\n",
                    c.getNombre(), c.getF(), c.getFr(), c.getPorc());
            suma += c.getF();
        }
        System.out.println("------------------------------");
        System.out.printf("%-10s %-5d %-6.2f %-6.1f\n", "TOTAL", suma, 1.0, 100.0);
    }

    // ============================
    //   HANDS-ON 4
    // ============================
    private void crearHO4() {

        t4 = new ArrayList<>();
        Arrays.sort(datos);

        int n = datos.length;
        double a = datos[0];
        double b = datos[n - 1];

        double rango = b - a;

        int k = (int) Math.ceil(1 + 3.322 * Math.log10(n));
        double ancho = Math.ceil(rango / k);

        double ini = a;

        for (int i = 0; i < k; i++) {
            double fin = ini + ancho;
            t4.add(new Categoria(ini, fin));
            ini = fin;
        }

        // Contar f
        for (double x : datos) {
            for (Categoria c : t4) {
                if ((x >= c.getLi() && x < c.getLs()) || x == b) {
                    c.sumar();
                    break;
                }
            }
        }

        // Calcular fr, fac, frac
        int fac = 0;
        double frac = 0;

        for (Categoria c : t4) {
            double fr = (double) c.getF() / n;
            c.setFr(fr);

            fac += c.getF();
            frac += fr;

            c.setFac(fac);
            c.setFrac(frac);
        }
    }

    public void imprimirHO4() {
        System.out.println("\n----- HANDS-ON 4 -----");
        System.out.printf("%-15s %-5s %-6s %-6s %-7s %-8s %-6s\n",
                "Intervalo", "f", "fr", "%", "FA", "FR Ac", "PM");

        for (Categoria c : t4) {
            System.out.printf("%6.1f-%-6.1f %-5d %-6.2f %-6.1f %-7d %-8.2f %-6.1f\n",
                    c.getLi(), c.getLs(),
                    c.getF(), c.getFr(), c.getPorc(),
                    c.getFac(), c.getFrac(),
                    c.getMid());
        }
    }

    // ============================
    //   HANDS-ON 5
    // ============================

    public void imprimirHO5() {
        System.out.println("\n----- HANDS-ON 5 -----");
        System.out.printf("Media: %.2f\n", media());
        System.out.printf("Moda: %.2f\n", moda());
        System.out.printf("Mediana: %.2f\n", mediana());
    }

    private double media() {
        double suma = 0;
        int n = datos.length;

        for (Categoria c : t4) suma += c.getMid() * c.getF();

        return suma / n;
    }

    private double moda() {
        Categoria mayor = t4.get(0);

        for (Categoria c : t4)
            if (c.getF() > mayor.getF())
                mayor = c;

        int pos = t4.indexOf(mayor);

        double Li = mayor.getLi();
        double fm = mayor.getF();
        double f1 = (pos == 0) ? 0 : t4.get(pos - 1).getF();
        double f2 = (pos == t4.size() - 1) ? 0 : t4.get(pos + 1).getF();
        double h = mayor.getLs() - mayor.getLi();

        return Li + ((fm - f1) / ((2 * fm) - f1 - f2)) * h;
    }

    private double mediana() {

        int N = datos.length;
        int mitad = N / 2;

        Categoria med = null;

        for (Categoria c : t4) {
            if (c.getFac() >= mitad) {
                med = c;
                break;
            }
        }

        int pos = t4.indexOf(med);

        double Li = med.getLi();
        double h = med.getLs() - med.getLi();
        int facPrev = (pos == 0) ? 0 : t4.get(pos - 1).getFac();
        int f = med.getF();

        return Li + ((double)(mitad - facPrev) / f) * h;
    }
}
