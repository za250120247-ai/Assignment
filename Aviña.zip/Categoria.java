public class Categoria {

    private String nombre;

    private double li, ls;   // solo se usan para HO4 y HO5
    private double mid;      // punto medio

    private int f;           // frecuencia
    private double fr;       // frecuencia relativa
    private double frac;     // fr acumulada
    private int fac;         // fa acumulada

    // --- Constructor para HO3 ---
    public Categoria(String nombre, int f, int total) {
        this.nombre = nombre;
        this.f = f;
        this.fr = (double) f / total;
    }

    // --- Constructor para HO4 ---
    public Categoria(double li, double ls) {
        this.li = li;
        this.ls = ls;
        this.mid = (li + ls) / 2.0;
    }

    public void sumar() { f++; }

    // getters
    public String getNombre() { return nombre; }
    public double getLi() { return li; }
    public double getLs() { return ls; }
    public double getMid() { return mid; }
    public int getF() { return f; }

    public double getFr() { return fr; }
    public double getFrac() { return frac; }
    public int getFac() { return fac; }

    public double getPorc() { return fr * 100; }

    // setters
    public void setFr(double fr) { this.fr = fr; }
    public void setFrac(double frac) { this.frac = frac; }
    public void setFac(int fac) { this.fac = fac; }
}
