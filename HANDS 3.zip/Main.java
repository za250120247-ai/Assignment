public class Main {
    public static void main(String[] args) {

        // Dataset hardcoded (como pide el Hands-on 3)
        String[] nombres = {"Carro", "Avión", "Tren", "Barco"};
        int[] frecuencias = {15, 13, 4, 8};

        // Crear tabla usando POO + herencia
        TablaFrecuencias tabla = new TablaFrecuencias(nombres, frecuencias);

        // Imprimir resultados
        tabla.imprimirTabla();
    }
}
