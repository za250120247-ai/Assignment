public class TablaFrecuencias {

    private Categoria[] categorias;
    private int total;

    public TablaFrecuencias(String[] nombres, int[] frecuencias) {
        // Calcular total
        total = 0;
        for (int f : frecuencias) total += f;

        // Crear categorías heredadas
        categorias = new Categoria[nombres.length];

        for (int i = 0; i < nombres.length; i++) {
            categorias[i] = new Categoria(nombres[i], frecuencias[i], total);
        }
    }

    public void imprimirTabla() {
        System.out.println("TABLA DE FRECUENCIAS");
        System.out.println("-------------------------------------------");
        System.out.printf("%-12s %-10s %-10s %-10s\n", "Clase", "f", "fr", "%");

        for (Categoria c : categorias) {
            System.out.printf("%-12s %-10d %-10.2f %-10.0f\n",
                    c.getNombre(),
                    c.getFrecuenciaAbsoluta(),
                    c.getFrecuenciaRelativa(),
                    c.getPorcentaje());
        }

        System.out.println("-------------------------------------------");
        System.out.printf("%-12s %-10d %-10.2f %-10s\n",
                "TOTAL", total, 1.00, "100%");
    }
}
