public class Categoria extends Dato {
    private double frecuenciaRelativa;
    private double porcentaje;

    public Categoria(String nombre, int frecuenciaAbsoluta, int totalDatos) {
        super(nombre, frecuenciaAbsoluta);  // ← HERENCIA

        this.frecuenciaRelativa = (double) frecuenciaAbsoluta / totalDatos;
        this.porcentaje = frecuenciaRelativa * 100;
    }

    public double getFrecuenciaRelativa() {
        return frecuenciaRelativa;
    }

    public double getPorcentaje() {
        return porcentaje;
    }
}
