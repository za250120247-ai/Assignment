public class Dato {
    protected String nombre;
    protected int frecuenciaAbsoluta;

    public Dato(String nombre, int frecuenciaAbsoluta) {
        this.nombre = nombre;
        this.frecuenciaAbsoluta = frecuenciaAbsoluta;
    }

    public String getNombre() {
        return nombre;
    }

    public int getFrecuenciaAbsoluta() {
        return frecuenciaAbsoluta;
    }
}
