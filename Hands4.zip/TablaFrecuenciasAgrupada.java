import java.util.Arrays;

public class TablaFrecuenciasAgrupada {

    private double[] datos;
    private ClaseAgrupada[] clases;

    public TablaFrecuenciasAgrupada(double[] datos) {
        this.datos = datos;
    }

    public void procesarDatos() {

        Arrays.sort(datos);
        int n = datos.length;

        // Número de clases usando Sturges
        int k = (int) Math.ceil(1 + 3.322 * Math.log10(n));

        // Rango y amplitud
        double rango = datos[n - 1] - datos[0];
        double amplitud = Math.ceil(rango / k);

        // Crear clases
        clases = new ClaseAgrupada[k];

        double li = datos[0];
        for (int i = 0; i < k; i++) {
            double ls = li + amplitud;
            clases[i] = new ClaseAgrupada(li, ls);
            li = ls;
        }

        // Contar frecuencias
        for (double dato : datos) {
            for (ClaseAgrupada c : clases) {
                boolean pertenece;

                // Incluir el último intervalo de forma inclusiva
                if (c == clases[clases.length - 1]) {
                    pertenece = (dato >= c.getLimiteInferior() && dato <= c.getLimiteSuperior());
                } else {
                    pertenece = (dato >= c.getLimiteInferior() && dato < c.getLimiteSuperior());
                }

                if (pertenece) {
                    c.incrementarFrecuencia();
                    break;
                }
            }
        }

        // Calcular frecuencias acumuladas
        int fa = 0;
        double fra = 0;

        for (ClaseAgrupada c : clases) {
            fa += c.getFrecuencia();
            c.setFrecuenciaAcumulada(fa);

            double fr = (double) c.getFrecuencia() / n;
            c.setFrecuenciaRelativa(fr);

            fra += fr;
            c.setFrecuenciaRelAcumulada(fra);
        }
    }

    public void imprimirTabla() {

        System.out.println("\nTabla de Frecuencias Agrupadas");
        System.out.printf("%-12s %-12s %-12s %-6s %-6s %-8s %-8s\n",
                "L. Inf", "L. Sup", "P. Medio", "f", "FA", "fr", "FRA");

        for (ClaseAgrupada c : clases) {
            System.out.printf("%-12.2f %-12.2f %-12.2f %-6d %-6d %-8.4f %-8.4f\n",
                    c.getLimiteInferior(),
                    c.getLimiteSuperior(),
                    c.getPuntoMedio(),
                    c.getFrecuencia(),
                    c.getFrecuenciaAcumulada(),
                    c.getFrecuenciaRelativa(),
                    c.getFrecuenciaRelAcumulada()
            );
        }
    }
}
