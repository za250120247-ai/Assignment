public class ClaseAgrupada extends Dato {

    private double limiteInferior;
    private double limiteSuperior;
    private double puntoMedio;

    private int frecuencia;
    private int frecuenciaAcumulada;

    private double frecuenciaRelativa;
    private double frecuenciaRelAcumulada;

    public ClaseAgrupada(double li, double ls) {
        super();
        this.limiteInferior = li;
        this.limiteSuperior = ls;

        this.puntoMedio = (li + ls) / 2.0;

        // Guardamos el punto medio en "valor" (herencia)
        this.valor = this.puntoMedio;

        this.frecuencia = 0;
    }

    public void incrementarFrecuencia() {
        frecuencia++;
    }

    // =============== GETTERS ===============

    public double getLimiteInferior() {
        return limiteInferior;
    }

    public double getLimiteSuperior() {
        return limiteSuperior;
    }

    public double getPuntoMedio() {
        return puntoMedio;
    }

    public int getFrecuencia() {
        return frecuencia;
    }

    public int getFrecuenciaAcumulada() {
        return frecuenciaAcumulada;
    }

    public double getFrecuenciaRelativa() {
        return frecuenciaRelativa;
    }

    public double getFrecuenciaRelAcumulada() {
        return frecuenciaRelAcumulada;
    }

    // =============== SETTERS ===============

    public void setFrecuenciaAcumulada(int fa) {
        this.frecuenciaAcumulada = fa;
    }

    public void setFrecuenciaRelativa(double fr) {
        this.frecuenciaRelativa = fr;
    }

    public void setFrecuenciaRelAcumulada(double fra) {
        this.frecuenciaRelAcumulada = fra;
    }
}
