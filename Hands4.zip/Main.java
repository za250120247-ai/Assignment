public class Main {
    public static void main(String[] args) {

        double[] datos = {
                12, 15, 22, 25, 27, 30, 31, 33, 34, 36,
                38, 40, 41, 42, 43, 45, 47, 49, 50, 51,
                52, 54, 55, 57, 58, 60, 61, 63, 65, 67,
                70, 72, 75, 78, 80
        };

        TablaFrecuenciasAgrupada tabla = new TablaFrecuenciasAgrupada(datos);
        tabla.procesarDatos();
        tabla.imprimirTabla();
    }
}
